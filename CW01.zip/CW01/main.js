alert('Я - твій домашка!!!');

F = 0; // straight

m = 0; // weight

a = 0; // acceleration

document.write('**********************************');
document.write("<br>");

var F = prompt('Enter value for F');

console.log(F, 'straight');
document.write(F, ': straight (F)');
document.write("<br>");

var m = prompt('Enter value for m');
console.log(m, 'weight');
document.write(m, ': weight (m)');
document.write("<br>");



document.write('--------------------------------');
document.write("<br>");

a = F/m // формула для прискорення

console.log(a, 'acceleration');
document.write(a, ': acceleration (a)');
document.write("<br>");



document.write('----------------------------------');







